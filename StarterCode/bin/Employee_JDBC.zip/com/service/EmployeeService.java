package com.service;

import com.bean.Employee;
import com.dao.EmployeeDao;

public class EmployeeService {
	public Employee[] getAllEmployees() {
		EmployeeDao dao=new EmployeeDao();
		return dao.getAllEmployees();
	}
	
	public Employee getEmployeeDetails(long empNo) {
		EmployeeDao dao=new EmployeeDao();
		return dao.getEmployeeDetails(empNo);
	}
	
	public boolean addEmployee(Employee e) {
		EmployeeDao dao=new EmployeeDao();
		return dao.addEmployee(e);
	}
	
	public boolean deleteEmployee(long empNo) {
		EmployeeDao dao=new EmployeeDao();
		return dao.deleteEmployee(empNo);
	}
	
	public double updateEmployeeSalary(long empNo, double increment) {
		double newSalary=0;
		EmployeeDao dao=new EmployeeDao();
		boolean t=dao.updateEmployeeSalary(empNo, increment);
		if(t==true) {
			Employee e=getEmployeeDetails(empNo);
			newSalary=e.getSalary();
		}
		return newSalary;
	}
}
