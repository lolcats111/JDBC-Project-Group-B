package com.test;

import com.bean.Employee;
import com.service.EmployeeService;

public class EmployeeTeseter {
	public static void main(String[] args) {
		EmployeeService service=new EmployeeService();
		Employee[] arr=service.getAllEmployees();
		if(arr!=null) {
			System.out.println("================ Employee List ================");
			for(Employee e:arr) {
				if(e!=null) {
					System.out.println(e.getEmpNo()+":"+e.getName()+":"+e.getSalary());
				}
			}
		}
		System.out.println("================ Employee Search Result ================");
		Employee e=service.getEmployeeDetails(10003);
		if(e!=null) {
			System.out.println(e.getEmpNo()+":"+e.getName()+":"+e.getSalary());
		} else {
			System.out.println("Employee not found!!!");
		}
		System.out.println("================ Employee Insertion ================");
		Employee emp=new Employee(10006,"Cherry",2900.00);
		boolean t=service.addEmployee(emp);
		if(t==true) {
			System.out.println("Employee inserted successfully...");
		} else {
			System.out.println("Employee insertion failed...");
		}
		System.out.println("================ Employee Deletion ================");
		t=service.deleteEmployee(10006);
		if(t==true) {
			System.out.println("Employee deleted successfully...");
		} else {
			System.out.println("Employee deletion failed...");
		}
		System.out.println("================ Employee Updation ================");
		double salary=service.updateEmployeeSalary(10003, 250.00);
		System.out.println("New Salary:"+salary);
	}
}
